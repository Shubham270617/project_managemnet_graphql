import dotenv from "dotenv";
dotenv.config();

import express from "express";
import cors from "cors";
import http from "http";

import { ApolloServer } from "@apollo/server";
import { expressMiddleware } from "@apollo/server/express4";

import connectDB from "./config/db.js";
import typeDefs from "./graphql/schema.js";
import resolvers from "./graphql/resolvers/index.js";
import { verifyToken } from "./middleware/auth.js";

await connectDB();

const app = express();

app.use(cors());
app.use(express.json());

const server = new ApolloServer({
  typeDefs,
  resolvers,
});

await server.start();

app.use(
  "/graphql",
  cors(),
  express.json(), // data will come in parse formate
  expressMiddleware(server, {
    context: async ({ req }) => {
      const user = verifyToken(req);
      return { user };
    },
  }),
);

const httpServer = http.createServer(app);

httpServer.listen(process.env.PORT, () => {
  console.log(
    `🚀 Server running at http://localhost:${process.env.PORT}/graphql`,
  );
});

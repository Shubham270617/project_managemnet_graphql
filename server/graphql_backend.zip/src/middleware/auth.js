import jwt from "jsonwebtoken";

/*
  This function verifies JWT token
  and returns decoded user data
*/

export const verifyToken = (req) => {
  try {
    // Authorization header format:
    // "Bearer <token>"
    const authHeader = req.headers.authorization;

    if (!authHeader) {
      return null; // no token
    }

    const token = authHeader.split(" ")[1];

    if (!token) {
      return null;
    }

    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    return decoded; // { id, role }
  } catch (error) {
    return null; // invalid token
  }
};
